package com.cg.frs.ui;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.cg.frs.dto.FlatOwners;
import com.cg.frs.service.FlatRegistrationServiceImpl;
import com.cg.frs.service.IFlatRegistrationService;

public class Client {

	private static Scanner scanner=new Scanner(System.in);
	private static FlatOwners ownerDetails=new FlatOwners();
	private static IFlatRegistrationService flatRegistrationService=new FlatRegistrationServiceImpl();

	public static void main(String[] args) {

		int option;
		while(true) {

			System.out.println();
			System.out.println("Flat Registration System");
			System.out.println("------------");
			System.out.println("1.Register Flat");
			System.out.println("2.Exit");
			System.out.println();
			System.out.println("Enter option: ");

			option=scanner.nextInt();
			try {
				switch(option) {
				
				case 1:
					List<FlatOwners> ownerDetails=flatRegistrationService.getAllOwnerIds();
					Iterator<FlatOwners> iterator=ownerDetails.iterator();
					while(iterator.hasNext()) 
					{
						System.out.println(iterator.next());
					}
					System.out.println("Enter owner ID from above list: ");
					Integer ownerId=scanner.nextInt();
					System.out.println("Enter Flat Type [1--1BHK,2--2BHK]: ");
					Integer flatType=scanner.nextInt();
					System.out.println("Enter Flat Area in Square feet: ");
					Integer flatArea=scanner.nextInt();
					System.out.println("Enter desired rent amount: ");
					Float flatRent=scanner.nextFloat();
					System.out.println("Enter desired deposit amount: ");
					Float flatDeposit=scanner.nextFloat();
					
					Integer registrationID=flatRegistrationService.registerFlat(ownerId, flatType, flatArea, flatRent,flatDeposit);	
					System.out.println("Your Registration ID is: "+registrationID);
					
					
				break;
				case 2:
					System.out.println("Exiting System!!");
					System.exit(0);
					break;
				default:
					System.out.println("Enter a valid option[1or2]");	
				}
			}catch(Exception e) {
				e.printStackTrace();
			}

		}

	}

}