package com.cg.frs.dao;

import java.util.List;

import com.cg.frs.dto.FlatOwners;
import com.cg.frs.exception.RegistrationException;

public interface IFlatRegistrationDAO {

	Integer registerFlat(int ownerId,int flatType,int flatArea,float rentAmount,float depositAmount) throws RegistrationException;
	public List<FlatOwners> getAllOwnerIds()throws RegistrationException;
}
