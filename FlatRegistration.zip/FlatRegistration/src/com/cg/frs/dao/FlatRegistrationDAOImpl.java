package com.cg.frs.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.frs.dto.FlatOwners;
import com.cg.frs.exception.RegistrationException;
import com.cg.frs.util.DBConnection;

public class FlatRegistrationDAOImpl implements IFlatRegistrationDAO {

	@Override
	public Integer registerFlat(int ownerId, int flatType, int flatArea, float rentAmount, float depositAmount)
			throws RegistrationException {
		try(
				Connection connection=DBConnection.getConnection();
				PreparedStatement preparedStatement=connection.prepareStatement(QueryMapper.BOOK_FLAT);
				Statement statement=connection.createStatement();
				)
		{
			preparedStatement.setInt(1, ownerId);
			preparedStatement.setInt(2, flatType);
			preparedStatement.setInt(3, flatArea);
			preparedStatement.setFloat(4, rentAmount);
			preparedStatement.setFloat(5, depositAmount);

			int n=preparedStatement.executeUpdate();
			System.out.println("Flat Booking Successfull");
			if(n>0) {
				ResultSet resultSet=statement.executeQuery(QueryMapper.FLAT_BOOKING_NO);
				if(resultSet.next()) {
					Integer registerFlat=resultSet.getInt(1);
					return registerFlat;
				}
				else {
					return null;
				}
			}
			else
			{
				return null;
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}		
		return null;
	}

	@Override
	public List<FlatOwners> getAllOwnerIds() throws RegistrationException {
		int Count=0;
		try(Connection connection=DBConnection.getConnection();
				Statement statement=connection.createStatement();
				){
			ResultSet resultSet=statement.executeQuery(QueryMapper.DISPLAY_OWNERS);
			List<FlatOwners> ownerDetails=new ArrayList<>();
			while(resultSet.next()) {
				Count++; 
				FlatOwners details=new FlatOwners();
				details.setOwnerId(resultSet.getInt("owner_id"));
				details.setOwnerName(resultSet.getString("owner_name"));
				details.setMobile(resultSet.getString("mobile"));
				ownerDetails.add(details);
			}
			if(Count!=0) {
				return ownerDetails;
			}
			else {
				return null;
			}
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		return null;
		
	}

}
