package com.cg.frs.dao;

public class QueryMapper {
	public static final String DISPLAY_OWNERS="SELECT owner_id from flat_owners";
	public static final String BOOK_FLAT="INSERT INTO FLAT_REGISTRATION VALUES(flat_seq.NEXTVAL,?,?,?,?,?)";
	public static final String UPDATE_AVAILABLE_TRUCK="update registerFlat set availablenos = availablenos-? where truckid=?";
	public static final String FLAT_BOOKING_NO="SELECT flat_seq.CURRVAL from dual";
}
