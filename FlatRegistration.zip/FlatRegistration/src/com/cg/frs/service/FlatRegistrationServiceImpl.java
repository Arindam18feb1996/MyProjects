package com.cg.frs.service;

import java.util.List;

import com.cg.frs.dao.FlatRegistrationDAOImpl;
import com.cg.frs.dao.IFlatRegistrationDAO;
import com.cg.frs.dto.FlatOwners;
import com.cg.frs.exception.RegistrationException;

public class FlatRegistrationServiceImpl implements IFlatRegistrationService {
	
	IFlatRegistrationDAO flatRegistrationDAO = new FlatRegistrationDAOImpl();

	@Override
	public List<FlatOwners> getAllOwnerIds() throws RegistrationException {
		List<FlatOwners> ownerDetails=flatRegistrationDAO.getAllOwnerIds();
		return ownerDetails;
	}

	@Override
	public Integer registerFlat(Integer ownerId, Integer flatType, Integer flatArea, Float flatRent,
			Float flatDeposit)throws RegistrationException {
		try {
			Integer registrationID=flatRegistrationDAO.registerFlat(ownerId, flatType, flatArea, flatRent,flatDeposit);
			if(registrationID>0) {
				return registrationID;
			}else {
				return null;
			}
				
		}catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}

}
