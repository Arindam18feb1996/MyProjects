package com.cg.frs.service;

import java.util.List;

import com.cg.frs.dto.FlatOwners;
import com.cg.frs.exception.RegistrationException;

public interface IFlatRegistrationService {
	
	List<FlatOwners> getAllOwnerIds()throws RegistrationException;
	Integer registerFlat(Integer ownerId, Integer flatType, Integer flatArea, Float flatRent, Float flatDeposit) throws RegistrationException;
}
