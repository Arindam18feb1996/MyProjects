package com.cg.frs.dto;

public class FlatRegistrationDTO {
	private int flatRegNo;
	private int ownerId;
	private int flatType;
	private int flatArea;
	private float rentAmount;
	private float depositAmount;
	
	public FlatRegistrationDTO() {
		
	}

	public FlatRegistrationDTO(int flatRegNo, int ownerId, int flatType, int flatArea, float rentAmount,
			float depositAmount) {
		super();
		this.flatRegNo = flatRegNo;
		this.ownerId = ownerId;
		this.flatType = flatType;
		this.flatArea = flatArea;
		this.rentAmount = rentAmount;
		this.depositAmount = depositAmount;
	}

	public int getFlatRegNo() {
		return flatRegNo;
	}

	public void setFlatRegNo(int flatRegNo) {
		this.flatRegNo = flatRegNo;
	}

	public int getOwnerId() {
		return ownerId;
	}

	public void setOwnerId(int ownerId) {
		this.ownerId = ownerId;
	}

	public int getFlatType() {
		return flatType;
	}

	public void setFlatType(int flatType) {
		this.flatType = flatType;
	}

	public int getFlatArea() {
		return flatArea;
	}

	public void setFlatArea(int flatArea) {
		this.flatArea = flatArea;
	}

	public float getRentAmount() {
		return rentAmount;
	}

	public void setRentAmount(float rentAmount) {
		this.rentAmount = rentAmount;
	}

	public float getDepositAmount() {
		return depositAmount;
	}

	public void setDepositAmount(float depositAmount) {
		this.depositAmount = depositAmount;
	}

	@Override
	public String toString() {
		return "flat_registration [flatRegNo=" + flatRegNo + ", ownerId=" + ownerId + ", flatType=" + flatType
				+ ", flatArea=" + flatArea + ", rentAmount=" + rentAmount + ", depositAmount=" + depositAmount + "]";
	}		
}
