package com.cg.frs.dto;

public class FlatOwners {

	private int ownerId;
	private String ownerName;
	private String mobile;
	
	public FlatOwners() {
		
	}

	public FlatOwners(int ownerId, String ownerName, String mobile) {
		super();
		this.ownerId = ownerId;
		this.ownerName = ownerName;
		this.mobile = mobile;
	}

	public int getOwnerId() {
		return ownerId;
	}

	public void setOwnerId(int ownerId) {
		this.ownerId = ownerId;
	}

	public String getOwnerName() {
		return ownerName;
	}

	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	@Override
	public String toString() {
		return "Existing ownerIds are=" + ownerId;
	}

	
		
	
}
