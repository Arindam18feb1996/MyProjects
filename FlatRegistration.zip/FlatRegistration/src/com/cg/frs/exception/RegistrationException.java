package com.cg.frs.exception;

public class RegistrationException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6738870095413400728L;
	private String message;
	
	public RegistrationException() {
		
	}

	public RegistrationException(String message) {
		super();
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	@Override
	public String toString() {
		return "RegistrationException [message=" + message + "]";
	}
	
}
