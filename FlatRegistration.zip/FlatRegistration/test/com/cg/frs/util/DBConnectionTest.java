package com.cg.frs.util;

import static org.junit.Assert.*;

import java.sql.SQLException;

import org.junit.Test;

import com.cg.frs.exception.RegistrationException;

public class DBConnectionTest {

	@Test
	public void test() throws RegistrationException, SQLException {
		assertNotNull(DBConnection.getConnection());
	}

}
