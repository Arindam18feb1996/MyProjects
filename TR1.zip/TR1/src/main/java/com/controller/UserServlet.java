package com.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pojo.UserPojo;
import com.service.IUserService;
import com.service.UserServiceImpl;


@WebServlet("/UserServlet")
public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	IUserService userService=new UserServiceImpl();
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String userName=request.getParameter("username");
		String emailId=request.getParameter("emailid");
		String phone=request.getParameter("phone");
		String city=request.getParameter("city");
		
		UserPojo userPojo=new UserPojo();
		userPojo.setUserName(userName);
		userPojo.setEmailId(emailId);
		userPojo.setPhone(phone);
		userPojo.setCity(city);
		Integer userid=userService.insertUser(userPojo);
		if(userid != null) {
			userPojo.setUserId(userid);
			response.sendRedirect("pages/HiFriendsChaiPilo.html");
			
		}else {
			PrintWriter pw=response.getWriter();
			pw.println("<h1>Please Arpita details ta dao</h1>");
			RequestDispatcher rd=request.getRequestDispatcher("UserDetails.html");
			rd.include(request, response);
		}
		
	}

}
