package com.dao;

import com.pojo.LoginPojo;

public interface ILoginDao {
	public boolean checkUser(LoginPojo loginPojo);
}
