package com.dao;

public interface QueryMapper {

	public static final String LOGIN="select * from login where userid=? and userpassword=?";
	public static final String INSERT_DETAILS ="insert into userdetails (username,emailid,phone,city) values(?,?,?,?)";
	public static final String GET_USER_ID ="Select LAST_INSERT_ID()";
	
}
