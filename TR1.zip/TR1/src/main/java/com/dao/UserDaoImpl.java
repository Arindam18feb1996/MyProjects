package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.pojo.UserPojo;
import com.util.DBConnection;

public class UserDaoImpl implements IUserDao {

	@Override
	public Integer insertUser(UserPojo userPojo) {
		
		try(Connection connection=DBConnection.getSQLConnection();
			PreparedStatement preparedStatement=connection.prepareStatement(QueryMapper.INSERT_DETAILS);
				Statement statement=connection.createStatement();
				){
			preparedStatement.setString(1, userPojo.getUserName());
			preparedStatement.setString(2, userPojo.getEmailId());
			preparedStatement.setString(3, userPojo.getPhone());
			preparedStatement.setString(4, userPojo.getCity());
			
			int n=preparedStatement.executeUpdate();
			
			if(n>0) {
				ResultSet resultSet=statement.executeQuery(QueryMapper.GET_USER_ID);
				if(resultSet.next()) {
				Integer userId=resultSet.getInt(1);	
				return userId;
				}
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
			
		return null;
	}

}
