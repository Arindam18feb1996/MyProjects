package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.pojo.LoginPojo;
import com.util.DBConnection;

public class LoginDaoImpl implements ILoginDao {

	@Override
	public boolean checkUser(LoginPojo loginPojo) {
		try(Connection connection=DBConnection.getSQLConnection();
				PreparedStatement ps =connection.prepareStatement(QueryMapper.LOGIN);
				){
			
			ps.setInt(1, loginPojo.getUserId());
			ps.setString(2, loginPojo.getUserPassword());
			ResultSet rs =ps.executeQuery();
			if(rs.next()) {
				return true;
			}

			
		}catch(Exception e){
			e.printStackTrace();
		}	
		return false;
	}

}
