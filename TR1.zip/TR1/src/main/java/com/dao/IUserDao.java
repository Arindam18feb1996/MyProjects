package com.dao;

import com.pojo.UserPojo;

public interface IUserDao {
	public Integer insertUser(UserPojo userPojo);
}
