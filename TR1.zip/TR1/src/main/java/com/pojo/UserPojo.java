package com.pojo;

public class UserPojo {
	private int userId;
	private String userName;
	private String emailId;
	private String phone;
	private String city;

	public UserPojo() {

	}

	public UserPojo(String userName, String emailId, String phone, String city) {
		super();
		this.userName = userName;
		this.emailId = emailId;
		this.phone = phone;
		this.city = city;
	}
	

	public UserPojo(int userId, String userName, String emailId, String phone, String city) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.emailId = emailId;
		this.phone = phone;
		this.city = city;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@Override
	public String toString() {
		return "UserPojo [userId=" + userId + ", userName=" + userName + ", emailId=" + emailId + ", phone=" + phone
				+ ", city=" + city + "]";
	}

}
