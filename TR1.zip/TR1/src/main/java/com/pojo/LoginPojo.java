package com.pojo;

public class LoginPojo {
	
	private int userId;
	private String userPassword;
	
	public LoginPojo() {
		super();
	}

	public LoginPojo(int userId, String userPassword) {
		super();
		this.userId = userId;
		this.userPassword = userPassword;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserPassword() {
		return userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

	@Override
	public String toString() {
		return "LoginPojo [userId=" + userId + ", userPassword=" + userPassword + "]";
	}	
	
}
