package com.service;


import com.dao.ILoginDao;
import com.dao.LoginDaoImpl;
import com.pojo.LoginPojo;

public class LoginServiceImpl implements ILoginService {

	ILoginDao loginDao=new LoginDaoImpl();
	@Override
	public boolean checkUser(LoginPojo loginPojo) {
		if(loginDao.checkUser(loginPojo)) {
			return true;
		}else {
			return false;
	}
	}
	
	
	
}
