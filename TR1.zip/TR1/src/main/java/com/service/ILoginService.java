package com.service;

import com.pojo.LoginPojo;

public interface ILoginService {

	public boolean checkUser(LoginPojo loginPojo);
}
