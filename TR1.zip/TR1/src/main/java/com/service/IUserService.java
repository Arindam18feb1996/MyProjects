package com.service;

import com.pojo.UserPojo;

public interface IUserService {

	public Integer insertUser(UserPojo userPojo);
	
}
