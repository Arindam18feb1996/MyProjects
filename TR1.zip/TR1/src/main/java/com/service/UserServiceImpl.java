package com.service;

import com.dao.IUserDao;
import com.dao.UserDaoImpl;
import com.pojo.UserPojo;

public class UserServiceImpl implements IUserService {

	IUserDao userDao=new UserDaoImpl();
	@Override
	public Integer insertUser(UserPojo userPojo) {
		Integer userId=userDao.insertUser(userPojo);
		if(userId>0)
		{
			return userId;
		}
		return null;
	}

}
