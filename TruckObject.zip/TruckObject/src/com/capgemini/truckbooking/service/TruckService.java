package com.capgemini.truckbooking.service;

import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.truckbooking.bean.TruckBean;
import com.capgemini.truckbooking.dao.ITruckDao;
import com.capgemini.truckbooking.dao.TruckDao;
import com.capgemini.truckbooking.exception.BookingException;

public class TruckService implements ITruckService{
	private static Logger myUILogger=Logger.getLogger(TruckService.class);
	Scanner scanner=new Scanner(System.in);
	ITruckDao truckDAO=new TruckDao();
	
	@Override
	public List<TruckBean> retrieveTruckDetails() throws BookingException {
		
		List<TruckBean> truckDetails=truckDAO.retrieveTruckDetails();
		return truckDetails;
	}

	@Override
	public Integer bookTrucks(BookingBean bookingobj)
			throws BookingException {	
		try {
			Integer BookingId=truckDAO.bookTrucks(bookingobj);
			if(bookingobj.getBookingID()>0) {
				return BookingId;
			}
			
		}
		catch(Exception e) {
			myUILogger.error(e);
			scanner.nextLine();
			System.err.println("Please check the loggers");
		}
		return null;
	}

	@Override
	public Boolean isValidTruckId(Integer truckId) throws BookingException {
		return truckDAO.isValidTruckId(truckId);
	}

	@Override
	public Integer isValidAvailableNos(Integer truckId, Integer availableNos)
			throws BookingException {
		try {
			Integer availableTrucks=truckDAO.isValidAvailableNos(truckId,availableNos);
			return availableTrucks;
		}catch(Exception e){
			myUILogger.error(e);
			scanner.nextLine();
			System.err.println("Please check the loggers");
		}
		return null;
	}

	@Override
	public String deleteTruck(Integer truckId) throws BookingException {	
		return truckDAO.deleteTruck(truckId);
	}

	

}
