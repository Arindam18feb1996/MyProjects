package com.capgemini.truckbooking.dao;

import java.util.List;


import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.truckbooking.bean.TruckBean;
import com.capgemini.truckbooking.exception.BookingException;

public interface ITruckDao {
	List<TruckBean> retrieveTruckDetails()throws BookingException ;
	public String deleteTruck(Integer truckId) throws BookingException;
	Integer bookTrucks(BookingBean bookingobj)throws BookingException;
	public Boolean isValidTruckId(Integer truckId)throws BookingException;
	Integer isValidAvailableNos(Integer truckId, Integer availableNos)throws BookingException;
}
