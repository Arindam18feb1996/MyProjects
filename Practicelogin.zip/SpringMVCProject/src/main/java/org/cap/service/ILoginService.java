package org.cap.service;

import org.cap.model.Login;

public interface ILoginService {
	public boolean validLogin(String userName, String userPwd);
}
