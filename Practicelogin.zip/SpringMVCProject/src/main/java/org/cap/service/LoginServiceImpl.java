package org.cap.service;

import org.cap.dao.ILoginDAO;
import org.cap.model.Login;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service("LoginService")
public class LoginServiceImpl implements ILoginService {

	@Autowired	
	private ILoginDAO loginDao;	
	@Override
	public boolean validLogin(String userName, String userPwd) {
		return loginDao.validLogin(userName,userPwd);
	}

}
