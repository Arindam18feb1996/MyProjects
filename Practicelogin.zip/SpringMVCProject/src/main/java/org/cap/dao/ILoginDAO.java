package org.cap.dao;

import org.cap.model.Login;

public interface ILoginDAO {

	public boolean validLogin(String userName, String userPwd);
}
