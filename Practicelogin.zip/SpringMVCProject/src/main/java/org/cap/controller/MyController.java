package org.cap.controller;

import org.cap.service.ILoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MyController {

	@Autowired
	private ILoginService loginService;
	
	
	@RequestMapping(value="/validateLogin",method=RequestMethod.POST)
	public String validateLogin(
			@RequestParam("userName") String userName,
			@RequestParam("userPwd") String userPwd,
			ModelMap map) {
		if(loginService.validLogin(userName,userPwd)) {
			map.addAttribute("userName",  userName);
			return "success";
		}
		else
			
			return "redirect:/";		
	}
	
}
